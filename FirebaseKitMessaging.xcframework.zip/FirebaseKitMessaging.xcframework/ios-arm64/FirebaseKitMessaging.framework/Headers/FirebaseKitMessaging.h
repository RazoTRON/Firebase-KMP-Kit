#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class FIRMessaging, FKMCPMIFIRMessagingAPNSTokenType, FKMCPMIFIRMessagingAPNSTokenTypeCompanion, FKMCoreFirebase, FKMKotlinArray<T>, FKMKotlinEnum<E>, FKMKotlinEnumCompanion, FKMKotlinException, FKMKotlinIllegalStateException, FKMKotlinRuntimeException, FKMKotlinThrowable, NSData, NSError;

@protocol FKMFirebaseMessaging, FKMKotlinCEnum, FKMKotlinComparable, FKMKotlinIterator, FKMMessagingBridge;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface FKMBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface FKMBase (FKMBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface FKMMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface FKMMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorFKMKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface FKMNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface FKMByte : FKMNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface FKMUByte : FKMNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface FKMShort : FKMNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface FKMUShort : FKMNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface FKMInt : FKMNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface FKMUInt : FKMNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface FKMLong : FKMNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface FKMULong : FKMNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface FKMFloat : FKMNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface FKMDouble : FKMNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface FKMBoolean : FKMNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((swift_name("MessagingBridge")))
@protocol FKMMessagingBridge
@required
- (void)deleteTokenWithCompletionCompletion:(void (^)(NSError * _Nullable))completion __attribute__((swift_name("deleteTokenWithCompletion(completion:)")));
- (void)setApnsTokenApnsToken:(NSData *)apnsToken __attribute__((swift_name("setApnsToken(apnsToken:)")));
- (void)setApnsTokenApnsToken:(NSData *)apnsToken type:(FKMCPMIFIRMessagingAPNSTokenType *)type __attribute__((swift_name("setApnsToken(apnsToken:type:)")));
- (void)subscribeToTopicTopic:(NSString *)topic completion:(void (^)(NSError * _Nullable))completion __attribute__((swift_name("subscribeToTopic(topic:completion:)")));
- (void)tokenWithCompletionCompletion:(void (^)(NSString * _Nullable, NSError * _Nullable))completion __attribute__((swift_name("tokenWithCompletion(completion:)")));
- (void)unsubscribeFromTopicTopic:(NSString *)topic completion:(void (^)(NSError * _Nullable))completion __attribute__((swift_name("unsubscribeFromTopic(topic:completion:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FIRMessagingBridge")))
@interface FKMFIRMessagingBridge : FKMBase <FKMMessagingBridge>
- (instancetype)initWithNative:(FIRMessaging *)native __attribute__((swift_name("init(native:)"))) __attribute__((objc_designated_initializer));
- (void)deleteTokenWithCompletionCompletion:(void (^)(NSError * _Nullable))completion __attribute__((swift_name("deleteTokenWithCompletion(completion:)")));
- (void)setApnsTokenApnsToken:(NSData *)apnsToken __attribute__((swift_name("setApnsToken(apnsToken:)")));
- (void)setApnsTokenApnsToken:(NSData *)apnsToken type:(FKMCPMIFIRMessagingAPNSTokenType *)type __attribute__((swift_name("setApnsToken(apnsToken:type:)")));
- (void)subscribeToTopicTopic:(NSString *)topic completion:(void (^)(NSError * _Nullable))completion __attribute__((swift_name("subscribeToTopic(topic:completion:)")));
- (void)tokenWithCompletionCompletion:(void (^)(NSString * _Nullable, NSError * _Nullable))completion __attribute__((swift_name("tokenWithCompletion(completion:)")));
- (void)unsubscribeFromTopicTopic:(NSString *)topic completion:(void (^)(NSError * _Nullable))completion __attribute__((swift_name("unsubscribeFromTopic(topic:completion:)")));
@end

__attribute__((swift_name("FirebaseMessaging")))
@protocol FKMFirebaseMessaging
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteTokenWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("deleteToken(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTokenWithCompletionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getToken(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)subscribeToTopicTopic:(NSString *)topic completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("subscribeToTopic(topic:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)unsubscribeFromTopicTopic:(NSString *)topic completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("unsubscribeFromTopic(topic:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FirebaseMessagingIos")))
@interface FKMFirebaseMessagingIos : FKMBase <FKMFirebaseMessaging>
- (instancetype)initWithMessaging:(id<FKMMessagingBridge>)messaging __attribute__((swift_name("init(messaging:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteTokenWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("deleteToken(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTokenWithCompletionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getToken(completionHandler:)")));
- (void)setApnsTokenApnsToken:(NSData *)apnsToken __attribute__((swift_name("setApnsToken(apnsToken:)")));
- (void)setApnsTokenApnsToken:(NSData *)apnsToken type:(FKMCPMIFIRMessagingAPNSTokenType *)type __attribute__((swift_name("setApnsToken(apnsToken:type:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)subscribeToTopicTopic:(NSString *)topic completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("subscribeToTopic(topic:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)unsubscribeFromTopicTopic:(NSString *)topic completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("unsubscribeFromTopic(topic:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CoreFirebase")))
@interface FKMCoreFirebase : FKMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)firebase __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) FKMCoreFirebase *shared __attribute__((swift_name("shared")));
@end

@interface FKMCoreFirebase (Extensions)
@property (readonly) id<FKMFirebaseMessaging> messaging __attribute__((swift_name("messaging")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FirebaseMessagingInstanceKt")))
@interface FKMFirebaseMessagingInstanceKt : FKMBase
+ (void)setFirebaseMessagingApnsTokenApnsToken:(NSData *)apnsToken __attribute__((swift_name("setFirebaseMessagingApnsToken(apnsToken:)")));
+ (void)setFirebaseMessagingApnsTokenApnsToken:(NSData *)apnsToken type:(FKMCPMIFIRMessagingAPNSTokenType *)type __attribute__((swift_name("setFirebaseMessagingApnsToken(apnsToken:type:)")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol FKMKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface FKMKotlinEnum<E> : FKMBase <FKMKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) FKMKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((swift_name("KotlinCEnum")))
@protocol FKMKotlinCEnum
@required
@property (readonly) id value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CPMIFIRMessagingAPNSTokenType")))
@interface FKMCPMIFIRMessagingAPNSTokenType : FKMKotlinEnum<FKMCPMIFIRMessagingAPNSTokenType *> <FKMKotlinCEnum>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) FKMCPMIFIRMessagingAPNSTokenTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) FKMCPMIFIRMessagingAPNSTokenType *firmessagingapnstokentypeunknown __attribute__((swift_name("firmessagingapnstokentypeunknown")));
@property (class, readonly) FKMCPMIFIRMessagingAPNSTokenType *firmessagingapnstokentypesandbox __attribute__((swift_name("firmessagingapnstokentypesandbox")));
@property (class, readonly) FKMCPMIFIRMessagingAPNSTokenType *firmessagingapnstokentypeprod __attribute__((swift_name("firmessagingapnstokentypeprod")));
+ (FKMKotlinArray<FKMCPMIFIRMessagingAPNSTokenType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<FKMCPMIFIRMessagingAPNSTokenType *> *entries __attribute__((swift_name("entries")));
@property (readonly) FKMLong *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface FKMKotlinThrowable : FKMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(FKMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(FKMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (FKMKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) FKMKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface FKMKotlinException : FKMKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(FKMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(FKMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface FKMKotlinRuntimeException : FKMKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(FKMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(FKMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface FKMKotlinIllegalStateException : FKMKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(FKMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(FKMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface FKMKotlinCancellationException : FKMKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(FKMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(FKMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface FKMKotlinEnumCompanion : FKMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) FKMKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CPMIFIRMessagingAPNSTokenType.Companion")))
@interface FKMCPMIFIRMessagingAPNSTokenTypeCompanion : FKMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) FKMCPMIFIRMessagingAPNSTokenTypeCompanion *shared __attribute__((swift_name("shared")));
- (FKMCPMIFIRMessagingAPNSTokenType *)byValueValue:(int64_t)value __attribute__((swift_name("byValue(value:)"))) __attribute__((deprecated("Will be removed.")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface FKMKotlinArray<T> : FKMBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(FKMInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<FKMKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol FKMKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
