#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class FIRRemoteConfig, FKRCCPMIFIRRemoteConfigFetchAndActivateStatus, FKRCCPMIFIRRemoteConfigFetchAndActivateStatusCompanion, FKRCCPMIFIRRemoteConfigFetchStatus, FKRCCPMIFIRRemoteConfigFetchStatusCompanion, FKRCCoreFirebase, FKRCKotlinArray<T>, FKRCKotlinEnum<E>, FKRCKotlinEnumCompanion, FKRCKotlinException, FKRCKotlinIllegalStateException, FKRCKotlinInstant, FKRCKotlinInstantCompanion, FKRCKotlinRuntimeException, FKRCKotlinThrowable, NSDate, NSError;

@protocol FKRCFirebaseRemoteConfig, FKRCKotlinCEnum, FKRCKotlinComparable, FKRCKotlinIterator, FKRCRemoteConfig, FKRCRemoteConfigSettings, FKRCRemoteConfigValue;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface FKRCBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface FKRCBase (FKRCBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface FKRCMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface FKRCMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorFKRCKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface FKRCNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface FKRCByte : FKRCNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface FKRCUByte : FKRCNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface FKRCShort : FKRCNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface FKRCUShort : FKRCNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface FKRCInt : FKRCNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface FKRCUInt : FKRCNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface FKRCLong : FKRCNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface FKRCULong : FKRCNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface FKRCFloat : FKRCNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface FKRCDouble : FKRCNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface FKRCBoolean : FKRCNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((swift_name("RemoteConfig")))
@protocol FKRCRemoteConfig
@required
- (id<FKRCRemoteConfigValue>)configValueForKeyKey:(NSString *)key __attribute__((swift_name("configValueForKey(key:)")));
- (void)fetchAndActivateWithCompletionHandlerCompletionHandler:(void (^ _Nullable)(FKRCCPMIFIRRemoteConfigFetchAndActivateStatus *, NSError * _Nullable))completionHandler __attribute__((swift_name("fetchAndActivateWithCompletionHandler(completionHandler:)")));
- (NSSet<id> *)keysWithPrefixPrefix:(NSString *)prefix __attribute__((swift_name("keysWithPrefix(prefix:)")));
@property (readonly) id<FKRCRemoteConfigSettings> configSettings __attribute__((swift_name("configSettings")));
@property (readonly) FKRCCPMIFIRRemoteConfigFetchStatus *lastFetchStatus __attribute__((swift_name("lastFetchStatus")));
@property (readonly) NSDate * _Nullable lastFetchTime __attribute__((swift_name("lastFetchTime")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FIRRemoteConfigBridge")))
@interface FKRCFIRRemoteConfigBridge : FKRCBase <FKRCRemoteConfig>
- (instancetype)initWithNative:(FIRRemoteConfig *)native __attribute__((swift_name("init(native:)"))) __attribute__((objc_designated_initializer));
- (id<FKRCRemoteConfigValue>)configValueForKeyKey:(NSString *)key __attribute__((swift_name("configValueForKey(key:)")));
- (void)fetchAndActivateWithCompletionHandlerCompletionHandler:(void (^ _Nullable)(FKRCCPMIFIRRemoteConfigFetchAndActivateStatus *, NSError * _Nullable))completionHandler __attribute__((swift_name("fetchAndActivateWithCompletionHandler(completionHandler:)")));
- (NSSet<id> *)keysWithPrefixPrefix:(NSString *)prefix __attribute__((swift_name("keysWithPrefix(prefix:)")));
@property (readonly) id<FKRCRemoteConfigSettings> configSettings __attribute__((swift_name("configSettings")));
@property (readonly) FKRCCPMIFIRRemoteConfigFetchStatus *lastFetchStatus __attribute__((swift_name("lastFetchStatus")));
@property (readonly) NSDate * _Nullable lastFetchTime __attribute__((swift_name("lastFetchTime")));
@end

__attribute__((swift_name("FirebaseRemoteConfig")))
@protocol FKRCFirebaseRemoteConfig
@required
- (NSString * _Nullable)allToJson __attribute__((swift_name("allToJson()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)fetchAndActivateWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("fetchAndActivate(completionHandler:)")));
- (FKRCBoolean * _Nullable)getBooleanKey:(NSString *)key __attribute__((swift_name("getBoolean(key:)")));
- (FKRCDouble * _Nullable)getDoubleKey:(NSString *)key __attribute__((swift_name("getDouble(key:)")));
- (FKRCInt * _Nullable)getIntKey:(NSString *)key __attribute__((swift_name("getInt(key:)")));
- (FKRCLong * _Nullable)getLongKey:(NSString *)key __attribute__((swift_name("getLong(key:)")));
- (NSString * _Nullable)getStringKey:(NSString *)key __attribute__((swift_name("getString(key:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FirebaseRemoteConfigIos")))
@interface FKRCFirebaseRemoteConfigIos : FKRCBase <FKRCFirebaseRemoteConfig>
- (instancetype)initWithRemoteConfig:(id<FKRCRemoteConfig>)remoteConfig __attribute__((swift_name("init(remoteConfig:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)allToJson __attribute__((swift_name("allToJson()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)fetchAndActivateWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("fetchAndActivate(completionHandler:)")));
- (FKRCBoolean *)getBooleanKey:(NSString *)key __attribute__((swift_name("getBoolean(key:)")));
- (FKRCDouble * _Nullable)getDoubleKey:(NSString *)key __attribute__((swift_name("getDouble(key:)")));
- (FKRCInt *)getIntKey:(NSString *)key __attribute__((swift_name("getInt(key:)")));
- (NSString *)getLastFetchStatus __attribute__((swift_name("getLastFetchStatus()")));
- (FKRCKotlinInstant * _Nullable)getLastFetchTime __attribute__((swift_name("getLastFetchTime()")));
- (FKRCLong *)getLongKey:(NSString *)key __attribute__((swift_name("getLong(key:)")));
- (int64_t)getMinimumFetchInterval __attribute__((swift_name("getMinimumFetchInterval()")));
- (NSString *)getStringKey:(NSString *)key __attribute__((swift_name("getString(key:)")));
@end

__attribute__((swift_name("RemoteConfigSettings")))
@protocol FKRCRemoteConfigSettings
@required
@property (readonly) double minimumFetchInterval __attribute__((swift_name("minimumFetchInterval")));
@end

__attribute__((swift_name("RemoteConfigValue")))
@protocol FKRCRemoteConfigValue
@required
@property (readonly) BOOL boolValue __attribute__((swift_name("boolValue")));
@property (readonly) double doubleValue __attribute__((swift_name("doubleValue")));
@property (readonly) int32_t intValue __attribute__((swift_name("intValue")));
@property (readonly) int64_t longValue __attribute__((swift_name("longValue")));
@property (readonly) NSString *stringValue __attribute__((swift_name("stringValue")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CoreFirebase")))
@interface FKRCCoreFirebase : FKRCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)firebase __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) FKRCCoreFirebase *shared __attribute__((swift_name("shared")));
@end

@interface FKRCCoreFirebase (Extensions)
@property (readonly) id<FKRCFirebaseRemoteConfig> remoteConfig __attribute__((swift_name("remoteConfig")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemoteConfigSettingsKt")))
@interface FKRCRemoteConfigSettingsKt : FKRCBase
+ (void)setConfigSettings:(id<FKRCFirebaseRemoteConfig>)receiver interval:(int64_t)interval __attribute__((swift_name("setConfigSettings(_:interval:)")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol FKRCKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface FKRCKotlinEnum<E> : FKRCBase <FKRCKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) FKRCKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((swift_name("KotlinCEnum")))
@protocol FKRCKotlinCEnum
@required
@property (readonly) id value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CPMIFIRRemoteConfigFetchAndActivateStatus")))
@interface FKRCCPMIFIRRemoteConfigFetchAndActivateStatus : FKRCKotlinEnum<FKRCCPMIFIRRemoteConfigFetchAndActivateStatus *> <FKRCKotlinCEnum>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) FKRCCPMIFIRRemoteConfigFetchAndActivateStatusCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) FKRCCPMIFIRRemoteConfigFetchAndActivateStatus *firremoteconfigfetchandactivatestatussuccessfetchedfromremote __attribute__((swift_name("firremoteconfigfetchandactivatestatussuccessfetchedfromremote")));
@property (class, readonly) FKRCCPMIFIRRemoteConfigFetchAndActivateStatus *firremoteconfigfetchandactivatestatussuccessusingprefetcheddata __attribute__((swift_name("firremoteconfigfetchandactivatestatussuccessusingprefetcheddata")));
@property (class, readonly) FKRCCPMIFIRRemoteConfigFetchAndActivateStatus *firremoteconfigfetchandactivatestatuserror __attribute__((swift_name("firremoteconfigfetchandactivatestatuserror")));
+ (FKRCKotlinArray<FKRCCPMIFIRRemoteConfigFetchAndActivateStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<FKRCCPMIFIRRemoteConfigFetchAndActivateStatus *> *entries __attribute__((swift_name("entries")));
@property (readonly) FKRCLong *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CPMIFIRRemoteConfigFetchStatus")))
@interface FKRCCPMIFIRRemoteConfigFetchStatus : FKRCKotlinEnum<FKRCCPMIFIRRemoteConfigFetchStatus *> <FKRCKotlinCEnum>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) FKRCCPMIFIRRemoteConfigFetchStatusCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) FKRCCPMIFIRRemoteConfigFetchStatus *firremoteconfigfetchstatusnofetchyet __attribute__((swift_name("firremoteconfigfetchstatusnofetchyet")));
@property (class, readonly) FKRCCPMIFIRRemoteConfigFetchStatus *firremoteconfigfetchstatussuccess __attribute__((swift_name("firremoteconfigfetchstatussuccess")));
@property (class, readonly) FKRCCPMIFIRRemoteConfigFetchStatus *firremoteconfigfetchstatusfailure __attribute__((swift_name("firremoteconfigfetchstatusfailure")));
@property (class, readonly) FKRCCPMIFIRRemoteConfigFetchStatus *firremoteconfigfetchstatusthrottled __attribute__((swift_name("firremoteconfigfetchstatusthrottled")));
+ (FKRCKotlinArray<FKRCCPMIFIRRemoteConfigFetchStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<FKRCCPMIFIRRemoteConfigFetchStatus *> *entries __attribute__((swift_name("entries")));
@property (readonly) FKRCLong *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface FKRCKotlinThrowable : FKRCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(FKRCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(FKRCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (FKRCKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) FKRCKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface FKRCKotlinException : FKRCKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(FKRCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(FKRCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface FKRCKotlinRuntimeException : FKRCKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(FKRCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(FKRCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface FKRCKotlinIllegalStateException : FKRCKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(FKRCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(FKRCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface FKRCKotlinCancellationException : FKRCKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(FKRCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(FKRCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="2.3")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinInstant")))
@interface FKRCKotlinInstant : FKRCBase <FKRCKotlinComparable>
@property (class, readonly, getter=companion) FKRCKotlinInstantCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(FKRCKotlinInstant *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (FKRCKotlinInstant *)minusDuration:(int64_t)duration __attribute__((swift_name("minus(duration:)")));
- (int64_t)minusOther:(FKRCKotlinInstant *)other __attribute__((swift_name("minus(other:)")));
- (FKRCKotlinInstant *)plusDuration:(int64_t)duration __attribute__((swift_name("plus(duration:)")));
- (int64_t)toEpochMilliseconds __attribute__((swift_name("toEpochMilliseconds()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t epochSeconds __attribute__((swift_name("epochSeconds")));
@property (readonly) int32_t nanosecondsOfSecond __attribute__((swift_name("nanosecondsOfSecond")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface FKRCKotlinEnumCompanion : FKRCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) FKRCKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CPMIFIRRemoteConfigFetchAndActivateStatus.Companion")))
@interface FKRCCPMIFIRRemoteConfigFetchAndActivateStatusCompanion : FKRCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) FKRCCPMIFIRRemoteConfigFetchAndActivateStatusCompanion *shared __attribute__((swift_name("shared")));
- (FKRCCPMIFIRRemoteConfigFetchAndActivateStatus *)byValueValue:(int64_t)value __attribute__((swift_name("byValue(value:)"))) __attribute__((deprecated("Will be removed.")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface FKRCKotlinArray<T> : FKRCBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(FKRCInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<FKRCKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CPMIFIRRemoteConfigFetchStatus.Companion")))
@interface FKRCCPMIFIRRemoteConfigFetchStatusCompanion : FKRCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) FKRCCPMIFIRRemoteConfigFetchStatusCompanion *shared __attribute__((swift_name("shared")));
- (FKRCCPMIFIRRemoteConfigFetchStatus *)byValueValue:(int64_t)value __attribute__((swift_name("byValue(value:)"))) __attribute__((deprecated("Will be removed.")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinInstant.Companion")))
@interface FKRCKotlinInstantCompanion : FKRCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) FKRCKotlinInstantCompanion *shared __attribute__((swift_name("shared")));
- (FKRCKotlinInstant *)fromEpochMillisecondsEpochMilliseconds:(int64_t)epochMilliseconds __attribute__((swift_name("fromEpochMilliseconds(epochMilliseconds:)")));
- (FKRCKotlinInstant *)fromEpochSecondsEpochSeconds:(int64_t)epochSeconds nanosecondAdjustment:(int32_t)nanosecondAdjustment __attribute__((swift_name("fromEpochSeconds(epochSeconds:nanosecondAdjustment:)")));
- (FKRCKotlinInstant *)fromEpochSecondsEpochSeconds:(int64_t)epochSeconds nanosecondAdjustment_:(int64_t)nanosecondAdjustment __attribute__((swift_name("fromEpochSeconds(epochSeconds:nanosecondAdjustment_:)")));
- (FKRCKotlinInstant *)now __attribute__((swift_name("now()"))) __attribute__((unavailable("Use Clock.System.now() instead")));
- (FKRCKotlinInstant *)parseInput:(id)input __attribute__((swift_name("parse(input:)")));
- (FKRCKotlinInstant * _Nullable)parseOrNullInput:(id)input __attribute__((swift_name("parseOrNull(input:)")));
@property (readonly) FKRCKotlinInstant *DISTANT_FUTURE __attribute__((swift_name("DISTANT_FUTURE")));
@property (readonly) FKRCKotlinInstant *DISTANT_PAST __attribute__((swift_name("DISTANT_PAST")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol FKRCKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
