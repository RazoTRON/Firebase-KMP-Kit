#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class FIRHTTPMetric, FIRPerformance, FIRTrace, FKPCoreFirebase;

@protocol FKPFirebasePerformance, FKPHttpMetricBridge, FKPPerformanceBridge, FKPPerformanceHttpMetric, FKPPerformanceTrace, FKPTraceBridge;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface FKPBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface FKPBase (FKPBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface FKPMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface FKPMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorFKPKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface FKPNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface FKPByte : FKPNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface FKPUByte : FKPNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface FKPShort : FKPNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface FKPUShort : FKPNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface FKPInt : FKPNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface FKPUInt : FKPNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface FKPLong : FKPNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface FKPULong : FKPNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface FKPFloat : FKPNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface FKPDouble : FKPNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface FKPBoolean : FKPNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((swift_name("FirebasePerformance")))
@protocol FKPFirebasePerformance
@required
- (id<FKPPerformanceHttpMetric>)doNewHttpMetricUrl:(NSString *)url httpMethod:(NSString *)httpMethod __attribute__((swift_name("doNewHttpMetric(url:httpMethod:)")));
- (id<FKPPerformanceTrace>)doNewTraceName:(NSString *)name __attribute__((swift_name("doNewTrace(name:)")));
- (void)setPerformanceCollectionEnabledEnabled:(BOOL)enabled __attribute__((swift_name("setPerformanceCollectionEnabled(enabled:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FirebasePerformanceIos")))
@interface FKPFirebasePerformanceIos : FKPBase <FKPFirebasePerformance>
- (instancetype)initWithPerformance:(id<FKPPerformanceBridge>)performance __attribute__((swift_name("init(performance:)"))) __attribute__((objc_designated_initializer));
- (id<FKPPerformanceHttpMetric>)doNewHttpMetricUrl:(NSString *)url httpMethod:(NSString *)httpMethod __attribute__((swift_name("doNewHttpMetric(url:httpMethod:)")));
- (id<FKPPerformanceTrace>)doNewTraceName:(NSString *)name __attribute__((swift_name("doNewTrace(name:)")));
- (void)setPerformanceCollectionEnabledEnabled:(BOOL)enabled __attribute__((swift_name("setPerformanceCollectionEnabled(enabled:)")));
@end

__attribute__((swift_name("PerformanceHttpMetric")))
@protocol FKPPerformanceHttpMetric
@required
- (NSString * _Nullable)getAttributeName:(NSString *)name __attribute__((swift_name("getAttribute(name:)")));
- (NSDictionary<NSString *, NSString *> *)getAttributes __attribute__((swift_name("getAttributes()")));
- (void)putAttributeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("putAttribute(name:value:)")));
- (void)removeAttributeName:(NSString *)name __attribute__((swift_name("removeAttribute(name:)")));
- (void)setHttpResponseCodeCode:(int32_t)code __attribute__((swift_name("setHttpResponseCode(code:)")));
- (void)setRequestPayloadSizeBytes:(int64_t)bytes __attribute__((swift_name("setRequestPayloadSize(bytes:)")));
- (void)setResponseContentTypeContentType:(NSString * _Nullable)contentType __attribute__((swift_name("setResponseContentType(contentType:)")));
- (void)setResponsePayloadSizeBytes:(int64_t)bytes __attribute__((swift_name("setResponsePayloadSize(bytes:)")));
- (void)start __attribute__((swift_name("start()")));
- (void)stop __attribute__((swift_name("stop()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PerformanceHttpMetricIos")))
@interface FKPPerformanceHttpMetricIos : FKPBase <FKPPerformanceHttpMetric>
- (instancetype)initWithHttpMetric:(id<FKPHttpMetricBridge>)httpMetric __attribute__((swift_name("init(httpMetric:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)getAttributeName:(NSString *)name __attribute__((swift_name("getAttribute(name:)")));
- (NSDictionary<NSString *, NSString *> *)getAttributes __attribute__((swift_name("getAttributes()")));
- (void)putAttributeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("putAttribute(name:value:)")));
- (void)removeAttributeName:(NSString *)name __attribute__((swift_name("removeAttribute(name:)")));
- (void)setHttpResponseCodeCode:(int32_t)code __attribute__((swift_name("setHttpResponseCode(code:)")));
- (void)setRequestPayloadSizeBytes:(int64_t)bytes __attribute__((swift_name("setRequestPayloadSize(bytes:)")));
- (void)setResponseContentTypeContentType:(NSString * _Nullable)contentType __attribute__((swift_name("setResponseContentType(contentType:)")));
- (void)setResponsePayloadSizeBytes:(int64_t)bytes __attribute__((swift_name("setResponsePayloadSize(bytes:)")));
- (void)start __attribute__((swift_name("start()")));
- (void)stop __attribute__((swift_name("stop()")));
@end

__attribute__((swift_name("PerformanceTrace")))
@protocol FKPPerformanceTrace
@required
- (NSString * _Nullable)getAttributeName:(NSString *)name __attribute__((swift_name("getAttribute(name:)")));
- (NSDictionary<NSString *, NSString *> *)getAttributes __attribute__((swift_name("getAttributes()")));
- (int64_t)getMetricName:(NSString *)name __attribute__((swift_name("getMetric(name:)")));
- (void)incrementMetricName:(NSString *)name by:(int64_t)by __attribute__((swift_name("incrementMetric(name:by:)")));
- (void)putAttributeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("putAttribute(name:value:)")));
- (void)putMetricName:(NSString *)name value:(int64_t)value __attribute__((swift_name("putMetric(name:value:)")));
- (void)removeAttributeName:(NSString *)name __attribute__((swift_name("removeAttribute(name:)")));
- (void)start __attribute__((swift_name("start()")));
- (void)stop __attribute__((swift_name("stop()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PerformanceTraceIos")))
@interface FKPPerformanceTraceIos : FKPBase <FKPPerformanceTrace>
- (instancetype)initWithTrace:(id<FKPTraceBridge>)trace __attribute__((swift_name("init(trace:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)getAttributeName:(NSString *)name __attribute__((swift_name("getAttribute(name:)")));
- (NSDictionary<NSString *, NSString *> *)getAttributes __attribute__((swift_name("getAttributes()")));
- (int64_t)getMetricName:(NSString *)name __attribute__((swift_name("getMetric(name:)")));
- (void)incrementMetricName:(NSString *)name by:(int64_t)by __attribute__((swift_name("incrementMetric(name:by:)")));
- (void)putAttributeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("putAttribute(name:value:)")));
- (void)putMetricName:(NSString *)name value:(int64_t)value __attribute__((swift_name("putMetric(name:value:)")));
- (void)removeAttributeName:(NSString *)name __attribute__((swift_name("removeAttribute(name:)")));
- (void)start __attribute__((swift_name("start()")));
- (void)stop __attribute__((swift_name("stop()")));
@end

__attribute__((swift_name("HttpMetricBridge")))
@protocol FKPHttpMetricBridge
@required
- (NSString * _Nullable)getAttributeName:(NSString *)name __attribute__((swift_name("getAttribute(name:)")));
- (NSDictionary<NSString *, NSString *> *)getAttributes __attribute__((swift_name("getAttributes()")));
- (void)putAttributeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("putAttribute(name:value:)")));
- (void)removeAttributeName:(NSString *)name __attribute__((swift_name("removeAttribute(name:)")));
- (void)setHttpResponseCodeCode:(int32_t)code __attribute__((swift_name("setHttpResponseCode(code:)")));
- (void)setRequestPayloadSizeBytes:(int64_t)bytes __attribute__((swift_name("setRequestPayloadSize(bytes:)")));
- (void)setResponseContentTypeContentType:(NSString * _Nullable)contentType __attribute__((swift_name("setResponseContentType(contentType:)")));
- (void)setResponsePayloadSizeBytes:(int64_t)bytes __attribute__((swift_name("setResponsePayloadSize(bytes:)")));
- (void)start __attribute__((swift_name("start()")));
- (void)stop __attribute__((swift_name("stop()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FIRHttpMetricBridge")))
@interface FKPFIRHttpMetricBridge : FKPBase <FKPHttpMetricBridge>
- (instancetype)initWithNative:(FIRHTTPMetric *)native __attribute__((swift_name("init(native:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)getAttributeName:(NSString *)name __attribute__((swift_name("getAttribute(name:)")));
- (NSDictionary<NSString *, NSString *> *)getAttributes __attribute__((swift_name("getAttributes()")));
- (void)putAttributeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("putAttribute(name:value:)")));
- (void)removeAttributeName:(NSString *)name __attribute__((swift_name("removeAttribute(name:)")));
- (void)setHttpResponseCodeCode:(int32_t)code __attribute__((swift_name("setHttpResponseCode(code:)")));
- (void)setRequestPayloadSizeBytes:(int64_t)bytes __attribute__((swift_name("setRequestPayloadSize(bytes:)")));
- (void)setResponseContentTypeContentType:(NSString * _Nullable)contentType __attribute__((swift_name("setResponseContentType(contentType:)")));
- (void)setResponsePayloadSizeBytes:(int64_t)bytes __attribute__((swift_name("setResponsePayloadSize(bytes:)")));
- (void)start __attribute__((swift_name("start()")));
- (void)stop __attribute__((swift_name("stop()")));
@end

__attribute__((swift_name("PerformanceBridge")))
@protocol FKPPerformanceBridge
@required
- (id<FKPHttpMetricBridge> _Nullable)doNewHttpMetricUrl:(NSString *)url httpMethod:(NSString *)httpMethod __attribute__((swift_name("doNewHttpMetric(url:httpMethod:)")));
- (id<FKPTraceBridge> _Nullable)doNewTraceName:(NSString *)name __attribute__((swift_name("doNewTrace(name:)")));
- (void)setPerformanceCollectionEnabledEnabled:(BOOL)enabled __attribute__((swift_name("setPerformanceCollectionEnabled(enabled:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FIRPerformanceBridge")))
@interface FKPFIRPerformanceBridge : FKPBase <FKPPerformanceBridge>
- (instancetype)initWithNative:(FIRPerformance *)native __attribute__((swift_name("init(native:)"))) __attribute__((objc_designated_initializer));
- (id<FKPHttpMetricBridge> _Nullable)doNewHttpMetricUrl:(NSString *)url httpMethod:(NSString *)httpMethod __attribute__((swift_name("doNewHttpMetric(url:httpMethod:)")));
- (id<FKPTraceBridge> _Nullable)doNewTraceName:(NSString *)name __attribute__((swift_name("doNewTrace(name:)")));
- (void)setPerformanceCollectionEnabledEnabled:(BOOL)enabled __attribute__((swift_name("setPerformanceCollectionEnabled(enabled:)")));
@end

__attribute__((swift_name("TraceBridge")))
@protocol FKPTraceBridge
@required
- (NSString * _Nullable)getAttributeName:(NSString *)name __attribute__((swift_name("getAttribute(name:)")));
- (NSDictionary<NSString *, NSString *> *)getAttributes __attribute__((swift_name("getAttributes()")));
- (int64_t)getMetricName:(NSString *)name __attribute__((swift_name("getMetric(name:)")));
- (void)incrementMetricName:(NSString *)name by:(int64_t)by __attribute__((swift_name("incrementMetric(name:by:)")));
- (void)putAttributeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("putAttribute(name:value:)")));
- (void)putMetricName:(NSString *)name value:(int64_t)value __attribute__((swift_name("putMetric(name:value:)")));
- (void)removeAttributeName:(NSString *)name __attribute__((swift_name("removeAttribute(name:)")));
- (void)start __attribute__((swift_name("start()")));
- (void)stop __attribute__((swift_name("stop()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FIRTraceBridge")))
@interface FKPFIRTraceBridge : FKPBase <FKPTraceBridge>
- (instancetype)initWithNative:(FIRTrace *)native __attribute__((swift_name("init(native:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)getAttributeName:(NSString *)name __attribute__((swift_name("getAttribute(name:)")));
- (NSDictionary<NSString *, NSString *> *)getAttributes __attribute__((swift_name("getAttributes()")));
- (int64_t)getMetricName:(NSString *)name __attribute__((swift_name("getMetric(name:)")));
- (void)incrementMetricName:(NSString *)name by:(int64_t)by __attribute__((swift_name("incrementMetric(name:by:)")));
- (void)putAttributeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("putAttribute(name:value:)")));
- (void)putMetricName:(NSString *)name value:(int64_t)value __attribute__((swift_name("putMetric(name:value:)")));
- (void)removeAttributeName:(NSString *)name __attribute__((swift_name("removeAttribute(name:)")));
- (void)start __attribute__((swift_name("start()")));
- (void)stop __attribute__((swift_name("stop()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CoreFirebase")))
@interface FKPCoreFirebase : FKPBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)firebase __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) FKPCoreFirebase *shared __attribute__((swift_name("shared")));
@end

@interface FKPCoreFirebase (Extensions)
@property (readonly) id<FKPFirebasePerformance> performance __attribute__((swift_name("performance")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
